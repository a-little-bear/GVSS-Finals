package parabolaSimulation;

public class Keys{
	
	public Keys() {
		new parabolaSimulation.frame.TextFrame("Keys", "keys");
	}

}
