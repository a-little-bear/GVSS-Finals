package parabolaSimulation;

public class About{
	
	public About(){
		new parabolaSimulation.frame.TextFrame("About", "about");
	}
}
