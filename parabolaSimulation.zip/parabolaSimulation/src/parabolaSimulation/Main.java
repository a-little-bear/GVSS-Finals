package parabolaSimulation;

public class Main {
	public static void main(String[] args) {
		new parabolaSimulation.frame.MainFrame("Parabola Simulator");
	}
}
